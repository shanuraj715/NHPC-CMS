<?php
include '../web_files/config.php';
include '../web_files/db.php';
include './functions/functions.php';
checkLoginStatus();
?>