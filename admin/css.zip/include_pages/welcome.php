<div class="welcome_block">
	<!-- <img src="<?php echo $base_url;?>/admin/images/dashboard.png"> -->
	<div class="top_title_block">
		<span class="top_title">Welcome Back</span>
		<span class="user_name_text"><?php echo $_SESSION['fname'] . ' ' . $_SESSION['lname'];?></span>
	</div>
</div>